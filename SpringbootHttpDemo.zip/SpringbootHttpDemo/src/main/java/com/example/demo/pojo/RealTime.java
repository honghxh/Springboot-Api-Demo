package com.example.demo.pojo;

public class RealTime {

        private String week;
        private String wtId;
        private String wtNm;
        private String wtIcon;
        private String wtTemp;
        private String wtHumi;
        private String wtWindId;
        private String wtWindNm;
        private String wtWinp;
        private String wtWins;
        private String wtAqi;
        private String wtVisibility;
        private String wtRainfall;
        private String wtPressurel;
        public void setWeek(String week) {
            this.week = week;
        }
        public String getWeek() {
            return week;
        }

        public void setWtId(String wtId) {
            this.wtId = wtId;
        }
        public String getWtId() {
            return wtId;
        }

        public void setWtNm(String wtNm) {
            this.wtNm = wtNm;
        }
        public String getWtNm() {
            return wtNm;
        }

        public void setWtIcon(String wtIcon) {
            this.wtIcon = wtIcon;
        }
        public String getWtIcon() {
            return wtIcon;
        }

        public void setWtTemp(String wtTemp) {
            this.wtTemp = wtTemp;
        }
        public String getWtTemp() {
            return wtTemp;
        }

        public void setWtHumi(String wtHumi) {
            this.wtHumi = wtHumi;
        }
        public String getWtHumi() {
            return wtHumi;
        }

        public void setWtWindId(String wtWindId) {
            this.wtWindId = wtWindId;
        }
        public String getWtWindId() {
            return wtWindId;
        }

        public void setWtWindNm(String wtWindNm) {
            this.wtWindNm = wtWindNm;
        }
        public String getWtWindNm() {
            return wtWindNm;
        }

        public void setWtWinp(String wtWinp) {
            this.wtWinp = wtWinp;
        }
        public String getWtWinp() {
            return wtWinp;
        }

        public void setWtWins(String wtWins) {
            this.wtWins = wtWins;
        }
        public String getWtWins() {
            return wtWins;
        }

        public void setWtAqi(String wtAqi) {
            this.wtAqi = wtAqi;
        }
        public String getWtAqi() {
            return wtAqi;
        }

        public void setWtVisibility(String wtVisibility) {
            this.wtVisibility = wtVisibility;
        }
        public String getWtVisibility() {
            return wtVisibility;
        }

        public void setWtRainfall(String wtRainfall) {
            this.wtRainfall = wtRainfall;
        }
        public String getWtRainfall() {
            return wtRainfall;
        }

        public void setWtPressurel(String wtPressurel) {
            this.wtPressurel = wtPressurel;
        }
        public String getWtPressurel() {
            return wtPressurel;
        }

    @Override
    public String toString() {
        return "RealTime{" +
                "week='" + week + '\'' +
                ", wtId='" + wtId + '\'' +
                ", wtNm='" + wtNm + '\'' +
                ", wtIcon='" + wtIcon + '\'' +
                ", wtTemp='" + wtTemp + '\'' +
                ", wtHumi='" + wtHumi + '\'' +
                ", wtWindId='" + wtWindId + '\'' +
                ", wtWindNm='" + wtWindNm + '\'' +
                ", wtWinp='" + wtWinp + '\'' +
                ", wtWins='" + wtWins + '\'' +
                ", wtAqi='" + wtAqi + '\'' +
                ", wtVisibility='" + wtVisibility + '\'' +
                ", wtRainfall='" + wtRainfall + '\'' +
                ", wtPressurel='" + wtPressurel + '\'' +
                '}';
    }
}
